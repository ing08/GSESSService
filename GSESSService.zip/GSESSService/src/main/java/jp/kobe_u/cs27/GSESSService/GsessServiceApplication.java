package jp.kobe_u.cs27.GSESSService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsessServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GsessServiceApplication.class, args);
	}

}

package jp.kobe_u.cs27.GSESSService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GsessServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
